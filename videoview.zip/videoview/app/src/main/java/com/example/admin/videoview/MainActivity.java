package com.example.admin.videoview;

import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    VideoView Videos;
    MediaController mediaController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Videos=(VideoView)findViewById(R.id.videos);
        mediaController=new MediaController(this);
    }
        public void play(View view)
        {
            String videopath="android.resources://com.example.hp.Videoview/"+R.raw.small;
            Uri uri =Uri.parse(videopath);
            Videos.setVideoURI(uri);
            Videos.setMediaController(mediaController);
            mediaController.setAnchorView(Videos);
            Videos.start();


        }
    }

