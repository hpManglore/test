package com.example.manish.webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    WebView webView;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
     //   button=(Button)findViewById(R.id.button);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=(WebView)findViewById(R.id.webView);
       /* button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
//button.setOnClickListener(new View.onClickListener);

    }

    public void webpage(View view){
        webView.loadUrl("https://www.youtube.com/");

    }
}
