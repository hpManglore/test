package com.example.pp.webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
WebView WEB;
Button btn,btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WEB=(WebView)findViewById(R.id.web);
        btn=(Button) findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WEB.loadUrl("https://www.myntra.com/");
            }
        });

    }
    public void button(View view){
       WEB.loadUrl("https://www.youtube.com/");
    }
}
