package com.example.hp.webview;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    WebView webview;
    Button btn;
VideoView videoview;
MediaController media;
Button play;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webview = (WebView) findViewById(R.id.Web);
        btn = (Button) findViewById(R.id.button);
        videoview = (VideoView) findViewById(R.id.video);
        play=(Button)findViewById(R.id.button2);
        media = new MediaController(this);
    }
    public void play(View view) {
        String Videopath = "android resource://com.example.hp.webview/"+R.raw.video;
        Uri uri = Uri.parse(Videopath);
        videoview.setVideoURI(uri);
        videoview.setMediaController(media);
        media.setAnchorView(videoview);
        videoview.start();


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.loadUrl("https://www.javatpoint.com/android-webview-example");
            }
        });
    }
}