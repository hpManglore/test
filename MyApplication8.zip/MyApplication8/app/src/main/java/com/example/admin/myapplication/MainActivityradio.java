package com.example.admin.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivityradio extends AppCompatActivity {
    RadioGroup rgrp;
    RadioButton rb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activityradio);
        rgrp=(RadioGroup)findViewById(R.id.rahul);
    }
    public void onradioButtonClicked (View view){
        int checkedid=rgrp.getCheckedRadioButtonId();
        rb=(RadioButton)findViewById(checkedid);
        Toast.makeText(getApplicationContext(),rb.getText(), Toast.LENGTH_SHORT).show();
    }
}
