<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
	$id = $_POST['id'];
	require_once('db_Connect.php');
 
//	$sql = "INSERT INTO `register`(name,password,email,phoneno) VALUES ('$name','$password','$email','$phoneno')";
$sql="DELETE FROM `staff` WHERE `id`=$id";
	
	if(mysqli_query($conn,$sql)){
		echo "Success";
	}
 
	mysqli_close($conn);
	}else{
		echo "Error";
 }
?>