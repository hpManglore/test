package com.example.admin.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText abc;
    EditText def;
    TextView ghi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        abc=(EditText)findViewById(R.id.editText2);
        def=(EditText)findViewById(R.id.editText);
        ghi=(TextView)findViewById(R.id.textView);

    }

    public void addition(View view)
    {
int num1=Integer.parseInt(abc.getText().toString());
int num2=Integer.parseInt(def.getText().toString());
int sum=num1+num2;
ghi.setText(String.valueOf(sum));


    }
    public void subtraction(View view)
    {
        int num1=Integer.parseInt(abc.getText().toString());
        int num2=Integer.parseInt(def.getText().toString());
        int sub=num1-num2;
        ghi.setText(String.valueOf(sub));

    }
    public void division(View view)
    {
        int num1=Integer.parseInt(abc.getText().toString());
        int num2=Integer.parseInt(def.getText().toString());
        int div=num1/num2;
        ghi.setText(String.valueOf(div));

    }
    public void multiplication (View view)
    {
        int num1=Integer.parseInt(abc.getText().toString());
        int num2=Integer.parseInt(def.getText().toString());
        int mul=num1*num2;
        ghi.setText(String.valueOf(mul));

    }
}
