package com.example.vinith.date_picker;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
Button button;
TextView textView;
String date="";
int mdate;
int mmonth,myear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        textView=(TextView)findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datepicker();
            }
        });
    }
    private  void datepicker(){
        Calendar c=Calendar.getInstance();
        mdate=c.get(Calendar.DAY_OF_MONTH);
        mmonth=c.get(Calendar.MONTH);
        myear=c.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog= new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                myear=i;
                mmonth=i1;
                mdate=i2;
                date=mdate+"/"+(mmonth+1)+"/"+myear;
                textView.setText(date);


            }
        },myear,mdate,mmonth);
        datePickerDialog.show();
    }
}
