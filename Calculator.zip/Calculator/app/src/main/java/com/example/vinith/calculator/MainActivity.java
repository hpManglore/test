package com.example.vinith.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
 EditText abc,def ;
 TextView result;
 Button add,sub,mul,div;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        abc= (EditText) findViewById(R.id.editText2);
        def= (EditText) findViewById(R.id.editText);
        result = (TextView) findViewById(R.id.text);

        add=(Button)findViewById(R.id.button2);
        sub=(Button)findViewById(R.id.button4);
        mul=(Button)findViewById(R.id.button3);
        div=(Button)findViewById(R.id.button);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1=Integer.parseInt(abc.getText().toString());
                int num2=Integer.parseInt(def.getText().toString());
                int sum=num1+num2;
                result.setText(String.valueOf(sum));
                }

        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1=Integer.parseInt(abc.getText().toString());
                int num2=Integer.parseInt(def.getText().toString());
                int sum=num1-num2;
                result.setText(String.valueOf(sum));
            }

        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1=Integer.parseInt(abc.getText().toString());
                int num2=Integer.parseInt(def.getText().toString());
                int sum=num1*num2;
                result.setText(String.valueOf(sum));
            }

        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double num1=Integer.parseInt(abc.getText().toString());
                double num2=Integer.parseInt(def.getText().toString());
                double sum=num1/num2;
                result.setText(String.valueOf(sum));
            }

        });




    }



}



