package com.example.hp.mystyle;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
RadioButton r1,r2,r3,r4,r5,r6;
EditText ed1;
RadioGroup rb1,rb2;
Button b1;
TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1=(RadioButton)findViewById(R.id.r1);
        r2=(RadioButton)findViewById(R.id.r2);
        r3=(RadioButton)findViewById(R.id.r3);
        r4=(RadioButton)findViewById(R.id.r4);
        r5=(RadioButton)findViewById(R.id.r5);
        r6=(RadioButton)findViewById(R.id.r6);
        rb1=(RadioGroup)findViewById(R.id.rb1);
        rb2=(RadioGroup)findViewById(R.id.rb2);
        ed1=(EditText)findViewById(R.id.editText);
       t1=(TextView) findViewById(R.id.textView3);
        b1=(Button)findViewById(R.id.button);

rb1.setOnCheckedChangeListener(this);
rb2.setOnCheckedChangeListener(this);
b1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        t1.setText(ed1.getText().toString());
    }
});
       /* rb1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedid) {
                View rbtn = radioGroup.findViewById(checkedid);
                int index = radioGroup.indexOfChild(rbtn);


                switch (checkedid) {
                   // Typeface typeface,typeface1;
                    case R.id.r1:
//                        ed2.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                        break;
                    case R.id.r2:
                        Toast.makeText(getApplicationContext(), "clothes", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.r3:
                        break;
                }


            }
        });*/

    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {

        switch (i) {
            // Typeface typeface,typeface1;
            case R.id.r1:
                       t1.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL),Typeface.NORMAL);

                break;
            case R.id.r2:
              t1.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC),Typeface.ITALIC);
                break;
            case R.id.r3:t1.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD),Typeface.BOLD);
                break;
            case R.id.r4:t1.setGravity(Gravity.LEFT);
                break;
            case R.id.r5:t1.setGravity(Gravity.CENTER);
                break;
            case R.id.r6:t1.setGravity(Gravity.RIGHT);
                break;
        }

    }
}
