package com.example.sony.santury;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class staff extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);
    }
    public void insert(View v)
    {
        Intent i=new Intent(staff.this,staff_insert.class);
        startActivity(i);
    }
    public void delete(View v)
    {
        Intent i=new Intent(staff.this,staff_delete.class);
        startActivity(i);
    }
    public void close(View v)
    {
        Intent i=new Intent(staff.this,MainActivity.class);
        startActivity(i);
    }
    public void search(View v)
    {
        Intent i=new Intent(staff.this,staff_search.class);
        startActivity(i);
    }

}
