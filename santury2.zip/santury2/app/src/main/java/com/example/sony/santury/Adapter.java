package com.example.sony.santury;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public  class Adapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    Adapter.ViewHolder holder;
    public static Staff_search_details table1;




    public Adapter(Context context) {
        this.context = context;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return staff_search.detaillist.size();
    }



    @Override
    public Object getItem(int position) {
        return staff_search.detaillist.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        if(view == null){
            holder = new Adapter.ViewHolder();
            view = inflater.inflate(R.layout.staff_search_list,null);
            holder.text1 =(TextView)view.findViewById(R.id.text1);
            holder.text2 =(TextView)view.findViewById(R.id.text2);
            holder.text3 =(TextView)view.findViewById(R.id.text3);
            holder.text4 =(TextView)view.findViewById(R.id.text4);
            holder.text5 =(TextView)view.findViewById(R.id.text5);
            holder.text6 =(TextView)view.findViewById(R.id.text6);
            holder.text7 =(TextView)view.findViewById(R.id.text7);
            holder.text8 =(TextView)view.findViewById(R.id.text8);
            holder.text9 =(TextView)view.findViewById(R.id.text9);
            holder.text10 =(TextView)view.findViewById(R.id.text10);

            // view.setTag(holder);
        }else
        {
            holder = (Adapter.ViewHolder)view.getTag();
        }

        table1 = (Staff_search_details) getItem(position);

      /*  holder.text1.setTag(table);
        holder.text2.setTag(table);
        holder.text3.setTag(table);
        holder.text4.setTag(table);
        holder.text5.setTag(table);*/


        holder.text1.setText(String.valueOf(table1.getId()));
        holder.text2.setText(String.valueOf(table1.getFname()));
        holder.text3.setText(String.valueOf(table1.getLname()));
        holder.text4.setText(String.valueOf(table1.getDob()));
        holder.text5.setText(String.valueOf(table1.getAge()));
        holder.text6.setText(String.valueOf(table1.getSex()));
        holder.text7.setText(String.valueOf(table1.getDesignation()));
        holder.text8.setText(String.valueOf(table1.getSalary()));
        holder.text9.setText(String.valueOf(table1.getAddress()));
        holder.text10.setText(String.valueOf(table1.getContactno()));

        return view;

    }


    public static class ViewHolder{
        TextView text1,text2,text3,text4,text5,text6,text7,text8,text9,text10;
    }
}

