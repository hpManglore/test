package com.example.sony.santury;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class staff_search extends AppCompatActivity {
    String URL = "http://192.168.43.216/santury/search_staff.php";
    public static ArrayList<Staff_search_details> detaillist = new ArrayList<Staff_search_details>();
    public static Staff_search_details table1;
    Button b;
    Adapter adpter1;
    ListView listView;
    String id;
    Spinner spin;
    String semester[]={"1","2","3","4","5","6"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_search);
        spin=(Spinner)findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(staff_search.this,android.R.layout.simple_spinner_item,semester);
        spin.setAdapter(adapter);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long i) {
                id=semester[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
    public void submit(View v)
    {
        registerUser();
    }

    private void registerUser() {



        final ProgressDialog loading = ProgressDialog.show(this,"Uploading...","Please wait...",false,false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST,URL ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        loading.dismiss();

                        JSONObject jsonResponse;
                        try {

                            jsonResponse = new JSONObject(response);
                            JSONArray jsonArray = jsonResponse.getJSONArray("products");
                            for (int t = 0; t < jsonArray.length(); t++) {

                                JSONObject object = jsonArray.getJSONObject(t);
                                Staff_search_details table1 = new Staff_search_details();
                                table1.setId(object.getInt("id"));
                                table1.setFname(object.getString("Fname"));
                                table1.setLname(object.getString("Lname"));
                                table1.setDob(object.getString("dob"));
                                table1.setAge(object.getInt("age"));
                                table1.setSex(object.getString("sex"));
                                table1.setDesignation(object.getString("designation"));
                                table1.setSalary(object.getString("salary"));
                                table1.setAddress(object.getString("address"));
                                table1.setContactno(object.getString("contactno"));
                                detaillist.add(table1);

                            }

                        }catch (JSONException e) {

                            e.printStackTrace();
                        }

                        listView=(ListView)findViewById(R.id.listView);
                        adpter1=new com.example.sony.santury.Adapter(staff_search.this);
                        listView.setAdapter((ListAdapter) adpter1);


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        //Dismissing the progress dialog
                        loading.dismiss();
                        //Showing toast
                        Toast.makeText(staff_search.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String,String> params = new Hashtable<String, String>();

                params.put("id", id);


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    public void cancel(View v)
    {
        Toast.makeText(getApplicationContext(), "Thank You!!!", Toast.LENGTH_SHORT).show();
        Intent i=new Intent(staff_search.this,staff.class);
        startActivity(i);
    }
}