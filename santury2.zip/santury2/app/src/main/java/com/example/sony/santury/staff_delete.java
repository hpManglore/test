package com.example.sony.santury;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Hashtable;
import java.util.Map;

public class staff_delete extends AppCompatActivity {
    String url = "http://192.168.43.216/santury/delete_staff.php";
    EditText e;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_delete);
        e=(EditText)findViewById(R.id.editText4);
        b=(Button)findViewById(R.id.button11);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = e.getText().toString();

                if (id.isEmpty()) {
                    e.setError("enter staff id");
                }else {

                    uploaddetails();

                }

            }
        });
    }

    private void uploaddetails() {

        final ProgressDialog loading = ProgressDialog.show(this, "Uploading...", "Please wait...", false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    public void onResponse(String s) {
                        //Disimissing the progress dialog
                        loading.dismiss();
                        Toast.makeText(staff_delete.this, "Successfully deleted", Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {

                    public void onErrorResponse(VolleyError volleyError) {
                        //Dismissing the progress dialog+
                        loading.dismiss();
                        //Showing toast
                        Toast.makeText(staff_delete.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }) {

            protected Map<String, String> getParams() throws AuthFailureError {

                String u1 = e.getText().toString().trim();

                //Creating parameters
                Map<String, String> params = new Hashtable<String, String>();
                //Adding parameters
                params.put("id", u1);
                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }
    public void delete(View v)
    {
        Toast.makeText(getApplicationContext(), "Thank You!!!", Toast.LENGTH_SHORT).show();
        Intent i=new Intent(staff_delete.this,staff.class);
        startActivity(i);
    }
}
