package com.example.sony.santury;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Hashtable;
import java.util.Map;

public class staff_insert extends AppCompatActivity {
    EditText Fname, Lname, age, dob, designation, address, contactno, salary;
    RadioButton r1, r2;
    Button b1;
    String url = "http://192.168.43.216/santury/insert.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_insert);
        Fname = (EditText) findViewById(R.id.editText);
        Lname = (EditText) findViewById(R.id.editText2);
        age = (EditText) findViewById(R.id.editText3);
        contactno = (EditText) findViewById(R.id.editText9);
        salary = (EditText) findViewById(R.id.editText7);
        address = (EditText) findViewById(R.id.editText8);
        dob = (EditText) findViewById(R.id.editText5);
        designation = (EditText) findViewById(R.id.editText6);
        r1 = (RadioButton) findViewById(R.id.radioButton);
        r2 = (RadioButton) findViewById(R.id.radioButton2);
        b1 = (Button) findViewById(R.id.button9);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name1 = Fname.getText().toString();

                if (name1.isEmpty()) {
                    Fname.setError("enter firstname");
                } else if (Lname.getText().toString().isEmpty()) {
                    Lname.setError("enter lastname");
                } else if (age.getText().toString().isEmpty()) {
                    age.setError("enter age");
                } else if (contactno.getText().toString().isEmpty()) {
                    contactno.setError("enter number");
                } else if (salary.getText().toString().isEmpty()) {
                    salary.setError("enter salary");
                } else if (address.getText().toString().isEmpty()) {
                    address.setError("enter address");
                } else if (dob.getText().toString().isEmpty()) {
                    dob.setError("enter date of birth");
                } else if (designation.getText().toString().isEmpty()) {
                    designation.setError("enter designation");
                }else {

                    uploaddetails();

                }

            }
        });
    }

    private void uploaddetails() {

        final ProgressDialog loading = ProgressDialog.show(this, "Uploading...", "Please wait...", false, false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    public void onResponse(String s) {
                        //Disimissing the progress dialog
                        loading.dismiss();
                        Toast.makeText(staff_insert.this, "Successfully uploaded", Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {

                    public void onErrorResponse(VolleyError volleyError) {
                        //Dismissing the progress dialog+
                        loading.dismiss();
                        //Showing toast
                        Toast.makeText(staff_insert.this, volleyError.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                }) {

            protected Map<String, String> getParams() throws AuthFailureError {

                String u1 = Fname.getText().toString().trim();
                String u2 = Lname.getText().toString().trim();
                String a = age.getText().toString().trim();
                String d = dob.getText().toString().trim();
                String p = contactno.getText().toString().trim();
                String de = designation.getText().toString().trim();
                String s = salary.getText().toString().trim();
                String ad = address.getText().toString().trim();
                String g = null;
                if(r1.isChecked())
                {
                     g="male";
                }
                else if(r2.isChecked())
                {
                     g="female";
                }
                //Creating parameters
                Map<String, String> params = new Hashtable<String, String>();
                //Adding parameters
                params.put("Fname", u1);
                params.put("Lname", u2);
                params.put("dob", d);
                params.put("age", a);
                params.put("sex", g);
                params.put("designation", de);
                params.put("salary", s);
                params.put("address", ad);
                params.put("contactno", p);
                return params;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }
    public void onClick(View v)
    {
        Toast.makeText(getApplicationContext(), "Thank You!!!", Toast.LENGTH_SHORT).show();
        Intent i=new Intent(staff_insert.this,staff.class);
        startActivity(i);
    }
}
