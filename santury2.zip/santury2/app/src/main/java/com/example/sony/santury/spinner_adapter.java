package com.example.sony.santury;

public class spinner_adapter {
}
