package com.example.manish.myapplication;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class bbbbb extends android.support.v4.app.Fragment {


    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bbbbbb,container,false);
        return  view;
       // return super.onCreateView(inflater, container, savedInstanceState);
    }
}
