package com.example.manish.radiobutton;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rgrp;
    RadioButton rb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgrp=(RadioGroup)findViewById(R.id.manish);
    }

    public void onRadioButtonClicked(View view){
        int checkedid=rgrp.getCheckedRadioButtonId();
        rb=(RadioButton)findViewById(checkedid);
        Toast.makeText(getApplicationContext(),rb.getText(), Toast.LENGTH_SHORT).show();
    }


}
