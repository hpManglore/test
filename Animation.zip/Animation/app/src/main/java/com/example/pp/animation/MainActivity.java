package com.example.pp.animation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public  void rotate(View view){
        img=(ImageView)findViewById(R.id.imageview);
       /* btn=(Button)findViewById(R.id.button);*/
        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotation);
        img.startAnimation(animation);

    }
   /* public  void  clockwise(View view){

        Animation animation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotation);
        img.startAnimation(animation);
    }*/


    public  void  zoomin(View view){
        img=(ImageView)findViewById(R.id.imageview);
        Animation animation1= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomin);
        img.startAnimation(animation1);
    }



    public  void  zoomout(View view){
        img=(ImageView)findViewById(R.id.imageview);
        Animation animation1= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoomout);
        img.startAnimation(animation1);
    }


}