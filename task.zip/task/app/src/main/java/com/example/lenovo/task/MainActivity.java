package com.example.lenovo.task;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    Button btn;
    EditText TEXT;
    RadioGroup r1,r2;
    TextView text1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TEXT=(EditText)findViewById(R.id.editText);
        text1=(TextView)findViewById(R.id.textView);
        r1=(RadioGroup)findViewById(R.id.group1);
        r1.setOnCheckedChangeListener(this);
        r2=(RadioGroup)findViewById(R.id.group2);
        r2.setOnCheckedChangeListener(this);
        btn=(Button)findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text1.setText(TEXT.getText().toString());
            }
        });
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
      switch(checkedId){
          case R.id.radioButton5:
              text1.setGravity(Gravity.CENTER);
              break;
          case R.id.radioButton6:
              text1.setGravity(Gravity.LEFT);
              break;
          case R.id.radioButton4:
              text1.setGravity(Gravity.RIGHT);
              break;
          case R.id.radioButton:
               text1.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
               break;
          case R.id.radioButton2:
              text1.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
              break;
          case R.id.radioButton3:
              text1.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
              break;
      }
    }

}
