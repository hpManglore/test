package com.example.hp.webview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button search;
WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search = (Button)findViewById(R.id.search);
        web = (WebView)findViewById(R.id.web);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               web.loadUrl("http://www.javatpoint.com/andriod-webview-example");

                }

        });
    }
}
