package com.example.sony.sorting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Arrays;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {
EditText e,e1;
TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Asc(View v) {
        t = (TextView) findViewById(R.id.textView2);
        e1 = (EditText) findViewById(R.id.editText2);
        String s1 = e1.getText().toString();
        int[] n = new int[100];
        int i = 0, j, temp,a;
        StringTokenizer stk = new StringTokenizer(s1, ",");
        String[] b = new String[1000];
        while (stk.hasMoreTokens()) {
            b[i] = stk.nextToken();
            n[i] = Integer.parseInt(b[i]);
            i++;
        }
        a = i;
        if (i==0) {
            t.setText("");
            Toast.makeText(getApplicationContext(), "please enter the numbers", Toast.LENGTH_SHORT).show();
        } else {
            for (i = 0; i < a; i++) {
                for (j = 0; j < (a - i - 1); j++) {
                    if (n[j + 1] < n[j]) {
                        temp = n[j];
                        n[j] = n[j + 1];
                        n[j + 1] = temp;
                    }
                }
            }
            t.setText("");
            t.append("" + n[0]);
            for (i = 1; i < a; i++) {
                t.append("," + n[i]);
            }
        }
    }
public void Desc(View v)
 {
    t=(TextView)findViewById(R.id.textView2);
    e1=(EditText)findViewById(R.id.editText2);
    String s1=e1.getText().toString();
    int[] n=new int[100];
    int i=0,j,temp,a;
    StringTokenizer stk=new StringTokenizer(s1,",");
    String[] b=new String[1000];

    while(stk.hasMoreTokens())
    {
        b[i]=stk.nextToken();
        n[i] = Integer.parseInt(b[i]);
        i++;
    }
    a=i;
     if (i==0) {
         t.setText("");
         Toast.makeText(getApplicationContext(), "please enter the numbers", Toast.LENGTH_SHORT).show();
     } else {
         for (i = 0; i < a; i++) {
             for (j = 0; j < (a - i - 1); j++) {
                 if (n[j + 1] > n[j]) {
                     temp = n[j];
                     n[j] = n[j + 1];
                     n[j + 1] = temp;
                 }
             }
         }
         t.setText("");
         t.append("" + n[0]);
         for (i = 1; i < a; i++) {
             t.append("," + n[i]);
         }
     }
    }
}

