package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
  /*      button=(Button)findViewById(R.id.radioButton2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainActivity.this,Main2Activity.class);
                startActivity(i);
            }
        });*/
    }
    public void java(View view){

        Intent i=new Intent(MainActivity.this,Main2Activity.class);
        startActivity(i);
    } public void android(View view){

        Intent i=new Intent(MainActivity.this,Main3Activity.class);
        startActivity(i);
    }
    public void web(View view){

        Intent i=new Intent(MainActivity.this,Main4Activity.class);
        startActivity(i);
    }

}
