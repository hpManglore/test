package com.example.hp.proj1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    /*RadioGroup rgrp;
    RadioButton rb;
*/
    RadioGroup rb,rgrp;
    RadioButton r1,r2;
    CheckBox c1,c2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        //rgrp = (RadioGroup) findViewById(R.id.rh);
        rb = (RadioGroup) findViewById(R.id.rh);
        r1 = (RadioButton) findViewById(R.id.r3);
        r2 = (RadioButton) findViewById(R.id.r4);
        rb.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedid) {
                View rbtn = radioGroup.findViewById(checkedid);
                int index = radioGroup.indexOfChild(rbtn);
                switch (index) {
                    case 0:
                        Toast.makeText(getApplicationContext(), "books", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Toast.makeText(getApplicationContext(), "clothes", Toast.LENGTH_SHORT).show();
                        break;
                }


            }
        });
    /*
    StringBuffer str=new StringBuffer();
  String s1=c1.getText().toString();
        String s2=c2.getText().toString();
        if(c1.isSelected())
        {
            str.append(s1+"\n");
        }
        if(c2.isSelected())
        {
            str.append(s2+"\n");
        }*/
    /*public  void  Click(View view) {

       //int checkid=rgrp.getCheckedRadioButtonId();int index=
        //rb=(RadioButton)findViewById(checkid);
       // Toast.makeText(getApplicationContext(),rb.getText(),Toast.LENGTH_SHORT).show();
    switch (v.get
    {
        case  R.id.r3:Toast.makeText(getApplicationContext(),"hi",Toast.LENGTH_SHORT).show();
                   break;
        case 2:   Toast.makeText(getApplicationContext(),"helloe",Toast.LENGTH_SHORT).show();
            break;
    }
    }
?*/
    }
    public  void click(View vbv)
        {
            TextView e=(TextView)findViewById(R.id.t1);
            c1=(CheckBox)findViewById(R.id.c1);
            c2=(CheckBox)findViewById(R.id.c2);
            if(c1.isChecked())
                e.setText("music");
            if(c2.isChecked() )
                e.setText("sports");
            if(c1.isChecked() && c2.isChecked())
            e.setText("music,sports");
            if(!c1.isChecked() && !c2.isChecked())
                e.setText("");
        }

}
