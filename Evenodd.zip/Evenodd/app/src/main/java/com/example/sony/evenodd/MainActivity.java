package com.example.sony.evenodd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button b1;
EditText e;
Double d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void check(View v)
    {
        e=(EditText)findViewById(R.id.editText);
        String s=e.getText().toString();
        if("".equals(s.trim())) {
            Toast.makeText(getApplicationContext(),"please enter a number",Toast.LENGTH_SHORT).show();
        }
        else {
            d = Double.parseDouble(s);
            if (d % 2 == 0) {
                Toast.makeText(getApplicationContext(), e.getText() + " is even number", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), e.getText() + " is odd number", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
