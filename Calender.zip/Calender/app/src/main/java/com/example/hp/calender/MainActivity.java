package com.example.hp.calender;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
int mdate,mMONTH,mYear;
Button b1;
TextView  t1;
String date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.btn);
        t1=(TextView)findViewById(R.id.t1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datepicker();
            }
        });
    }

    private void datepicker() {
        Calendar c=Calendar.getInstance();
        mdate=c.get(Calendar.DAY_OF_MONTH);
        mMONTH=c.get(Calendar.MONTH);
        mYear=c.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                mYear=i;
                mMONTH=i1;
                mdate=i2;
                date=mdate+"/"+(mMONTH+1)+"/"+mYear;
                t1.setText(date);
            }
        },mdate,mMONTH,mYear);
        datePickerDialog.show();


    }
}
