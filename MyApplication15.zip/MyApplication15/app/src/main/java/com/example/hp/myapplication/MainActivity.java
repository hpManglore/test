package com.example.hp.myapplication;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    Button b1;
    TextView txt;
    int mdate;
    int mMonth;
    int mYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        txt=(TextView)findViewById(R.id.textView);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datepicker();
            }
        });
    }
    private void datepicker(){
        Calendar c=Calendar.getInstance();
        mdate=c.get(Calendar.DAY_OF_MONTH);
        mMonth=c.get(Calendar.MONTH);
        mYear=c.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                mYear=i;
                mMonth=i1;
                mdate=i2;
                date=mdate+"/"+(mMonth+1)+"/"+mYear;
                txt.setText(date);

            }
        },mdate,mMonth,mYear);
        datePickerDialog.show();
    }
}
