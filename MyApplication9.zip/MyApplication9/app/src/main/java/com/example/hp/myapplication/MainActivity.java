package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText no1, no2;
    Button add, sub, mul, div;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        no1=(EditText)findViewById(R.id.editText);
        no2=(EditText)findViewById(R.id.editText2);
        text=(TextView)findViewById(R.id.textView);

    }

    public void add(View v)
    {
int num=Integer.parseInt(no1.getText().toString());
int num1=Integer.parseInt(no2.getText().toString());
int num2=num+num1;
text.setText(String.valueOf(num2));

    }

    public void sub(View v)
    {
       /* String num=no1.getText().toString();
        String num1=no2.getText().toString();
        String num2=num-num1;
        text.setText(String.valueOf(num2));

*/      int num=Integer.parseInt(no1.getText().toString());
        int num1=Integer.parseInt(no2.getText().toString());
        int num2=num-num1;
        text.setText(String.valueOf(num2));



    }
    public void mul(View v)
    {
        int num=Integer.parseInt(no1.getText().toString());
        int num1=Integer.parseInt(no2.getText().toString());
        int num2=num*num1;
        text.setText(String.valueOf(num2));



    }
    public void div(View v)
    {
        int num=Integer.parseInt(no1.getText().toString());
        int num1=Integer.parseInt(no2.getText().toString());
        int num2=num/num1;
        text.setText(String.valueOf(num2));

    }

}