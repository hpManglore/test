package com.example.manish.spinnerlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.ActionMenuItemView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class second extends AppCompatActivity {
    ListView listView;
    String sem1[]={"MATHS","physics"};
    String sem2[]={"MATHS2","CHEMISTRY"};
    String sem3[]={"maths3","subject"};
    String string;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView=(ListView)findViewById(R.id.list);
        String mag=getIntent().getExtras().getString("title");

        if(mag.equals("sem2")){
            ArrayAdapter<String>adapter =new ArrayAdapter<String>(second.this,android.R.layout.simple_list_item_1,sem2);
            listView.setAdapter(adapter);
        }

        if(mag.equals("sem1")){
            ArrayAdapter<String>adapter =new ArrayAdapter<String>(second.this,android.R.layout.simple_list_item_1,sem1);
            listView.setAdapter(adapter);
        }
        if(mag.equals("sem3")){
            ArrayAdapter<String>adapter =new ArrayAdapter<String>(second.this,android.R.layout.simple_list_item_1,sem3);
            listView.setAdapter(adapter);
        }


    }
}
