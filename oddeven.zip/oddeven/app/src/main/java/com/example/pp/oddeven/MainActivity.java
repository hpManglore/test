package com.example.pp.oddeven;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText text;
    TextView text2;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        text = (EditText) findViewById(R.id.editText);
        text2 = (TextView) findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (text.getText().toString().isEmpty()) {
                    text.setError("enter value");
                }
                else
                {
                    int num = Integer.parseInt(text.getText().toString());

                    if (num% 2 == 0) {
                        text2.setText("even");
                    } else {

                        text2.setText("odd");
                    }
                }

            }
        });
    }
}
   /* public void check(View view){

        int num=Integer.parseInt(text.getText().toString());
        if(text.getText().toString().isEmpty())
        {
            text.setError(null);
            if(num%2==0)
            {
                text2.setText("even");
            }
            else{
                text2.setText("odd");
            }
        }
    }
}
*/