package com.example.hp.myapplication;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextSwitcher;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
Button btn;
TextView text;
EditText edit;
RadioButton rbtn;
RadioGroup style;
RadioGroup gravity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button)findViewById(R.id.button);
        edit=(EditText)findViewById(R.id.editText2);
        text=(TextView)findViewById(R.id.textView);
      style=(RadioGroup)findViewById(R.id.style);
     gravity=(RadioGroup)findViewById(R.id.gravity);
        style.setOnCheckedChangeListener(this);
        gravity.setOnCheckedChangeListener(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setText(edit.getText().toString());
            }
        });
    }


    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        switch(i) {
            case R.id.radioButton7:
                text.setGravity(Gravity.LEFT);
                break;
            case R.id.radioButton8:
                text.setGravity(Gravity.CENTER);
                break;
            case R.id.radioButton9:
                text.setGravity(Gravity.RIGHT);
                break;
            case R.id.radioButton4:
                text.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
                break;
            case R.id.radioButton5:
                text.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
                break;
            case R.id.radioButton6:
                text.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        }
    }
}
