package com.example.pp.spinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
String array[]= {"sem1","2nd sem","3rd sem"};
Spinner spinner;
/*ListView listView;*/
int str;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner=(Spinner)findViewById(R.id.spinner);
     /*   listView=(ListView) findViewById(R.id.listtview);
        ArrayAdapter<String>adapter1=new ArrayAdapter<String >(MainActivity.this,android.R.layout.simple_list_item_1,array);

       listView.setAdapter(adapter1);
       listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                           @Override
                                           public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                           }
                                       });*/
               ArrayAdapter<String>adapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,array);
               spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),array[i],Toast.LENGTH_SHORT).show();
                String str=array[i];
                Intent k=new Intent(MainActivity.this,Main2Activity.class);
                k.putExtra("item",str);
                startActivity(k);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
