package com.example.pp.spinner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {
    ListView listView;
    String array[] = {"ISE", "CSE"};
    String array1[] = {"A", "B"};
    String array2[] = {"1", "2"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.listview1);
        String msg = getIntent().getExtras().getString("item");
        if (msg.equals("sem1")) {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(Main2Activity.this, android.R.layout.simple_list_item_1, array);
            listView.setAdapter(adapter);
        }
        if (msg.equals("2nd sem")) {
            ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(Main2Activity.this, android.R.layout.simple_list_item_1, array1);
            listView.setAdapter(adapter1);
        }
        if (msg.equals("3rd sem")) {
            ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(Main2Activity.this, android.R.layout.simple_list_item_1, array2);
            listView.setAdapter(adapter2);
        }
    }

}