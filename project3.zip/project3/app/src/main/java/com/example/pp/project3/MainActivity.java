package com.example.pp.project3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button button;
CheckBox check1, check2, check3;
TextView TEXT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        check1=(CheckBox)findViewById(R.id.checkBox);
        check2=(CheckBox)findViewById(R.id.checkBox2);
        check3=(CheckBox)findViewById(R.id.checkBox3);
        TEXT=(TextView)findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String check = check1.getText().toString();
                String check4 = check2.getText().toString();
                String check5 = check3.getText().toString();
                StringBuffer str = new StringBuffer();
                if (check1.isChecked()) {
                    str.append(check);
                }
                if (check2.isChecked()) {
                    str.append(check4);
                }
                if (check3.isChecked()) {
                    str.append(check5);
                }
                TEXT.setText(str);
            }
        });
    }


}
